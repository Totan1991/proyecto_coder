from unicodedata import name
from django.urls import path
from mensajes import views
from django.contrib.auth.views import LogoutView




urlpatterns = [
   # path('', views.inicio),
    path('', views.consultar_comentario,name="mensajes"),
    path('nuevo_comentario/', views.nuevo_comentario,name="mensajes"),
    path('consultar_mensajes/', views.consultar_comentario,name="mensajes"),
    


]