from django.contrib import admin
from AppCoder.models import *
# Register your models here.


admin.site.register(reserva)
admin.site.register(habitaciones)
admin.site.register(cliente)
admin.site.register(contactos)
admin.site.register(Avatar)
